const TOKEN_KEY = 'organic_shop_admin_token';

function escapeHtml(str) {
  return String(str).replace(/[&<>"']/g, (c) => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
  }[c]));
}

function getToken() { return localStorage.getItem(TOKEN_KEY); }
function setToken(t) { localStorage.setItem(TOKEN_KEY, t); }
function clearToken() { localStorage.removeItem(TOKEN_KEY); }

function showLogin() {
  document.getElementById('login-view').classList.remove('hidden');
  document.getElementById('admin-view').classList.add('hidden');
  document.getElementById('logout-btn').classList.add('hidden');
}

function showDashboard() {
  document.getElementById('login-view').classList.add('hidden');
  document.getElementById('admin-view').classList.remove('hidden');
  document.getElementById('logout-btn').classList.remove('hidden');
  loadProducts();
  loadOrders();
}

// ---------- Login ----------
document.getElementById('login-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const errorEl = document.getElementById('login-error');
  errorEl.classList.add('hidden');

  try {
    const { token } = await Api.login(
      document.getElementById('username').value.trim(),
      document.getElementById('password').value
    );
    setToken(token);
    showDashboard();
  } catch (err) {
    errorEl.textContent = err.message;
    errorEl.classList.remove('hidden');
  }
});

document.getElementById('logout-btn').addEventListener('click', () => {
  clearToken();
  showLogin();
});

// ---------- Tabs ----------
document.querySelectorAll('.admin-sidebar button').forEach((btn) => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.admin-sidebar button').forEach((b) => b.classList.remove('active'));
    btn.classList.add('active');
    document.getElementById('tab-products').classList.toggle('hidden', btn.dataset.tab !== 'products');
    document.getElementById('tab-orders').classList.toggle('hidden', btn.dataset.tab !== 'orders');
  });
});

// ---------- Products ----------
async function loadProducts() {
  const tbody = document.getElementById('product-table-body');
  try {
    const products = await Api.getProducts();
    tbody.innerHTML = products.map((p) => `
      <tr>
        <td>${escapeHtml(p.name)}</td>
        <td>${escapeHtml(p.category)}</td>
        <td>$${p.price.toFixed(2)} / ${escapeHtml(p.unit)}</td>
        <td>${p.stock}</td>
        <td class="table-actions">
          <button data-edit="${p.id}">Edit</button>
          <button class="danger" data-delete="${p.id}">Delete</button>
        </td>
      </tr>
    `).join('');
    window.__products = products;
  } catch (err) {
    tbody.innerHTML = `<tr><td colspan="5">Couldn't load products.</td></tr>`;
  }
}

document.getElementById('product-table-body').addEventListener('click', async (e) => {
  const editBtn = e.target.closest('[data-edit]');
  const delBtn = e.target.closest('[data-delete]');

  if (editBtn) {
    const product = (window.__products || []).find((p) => p.id === editBtn.dataset.edit);
    if (!product) return;
    fillProductForm(product);
  }

  if (delBtn) {
    if (!confirm('Delete this product?')) return;
    try {
      await Api.deleteProduct(delBtn.dataset.delete, getToken());
      loadProducts();
    } catch (err) {
      alert(err.message);
    }
  }
});

function fillProductForm(product) {
  document.getElementById('product-id').value = product.id;
  document.getElementById('p-name').value = product.name;
  document.getElementById('p-price').value = product.price;
  document.getElementById('p-unit').value = product.unit;
  document.getElementById('p-category').value = product.category;
  document.getElementById('p-icon').value = product.icon;
  document.getElementById('p-stock').value = product.stock;
  document.getElementById('p-description').value = product.description;
  document.getElementById('product-submit-btn').textContent = 'Save Changes';
  document.getElementById('product-cancel-btn').classList.remove('hidden');
}

function resetProductForm() {
  document.getElementById('product-form').reset();
  document.getElementById('product-id').value = '';
  document.getElementById('product-submit-btn').textContent = 'Add Product';
  document.getElementById('product-cancel-btn').classList.add('hidden');
}

document.getElementById('product-cancel-btn').addEventListener('click', resetProductForm);

document.getElementById('product-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const errorEl = document.getElementById('product-error');
  errorEl.classList.add('hidden');

  const id = document.getElementById('product-id').value;
  const payload = {
    name: document.getElementById('p-name').value.trim(),
    price: parseFloat(document.getElementById('p-price').value),
    unit: document.getElementById('p-unit').value.trim(),
    category: document.getElementById('p-category').value.trim() || 'other',
    icon: document.getElementById('p-icon').value,
    stock: parseInt(document.getElementById('p-stock').value, 10) || 0,
    description: document.getElementById('p-description').value.trim()
  };

  try {
    if (id) {
      await Api.updateProduct(id, payload, getToken());
    } else {
      await Api.createProduct(payload, getToken());
    }
    resetProductForm();
    loadProducts();
  } catch (err) {
    errorEl.textContent = err.message;
    errorEl.classList.remove('hidden');
  }
});

// ---------- Orders ----------
async function loadOrders() {
  const tbody = document.getElementById('order-table-body');
  try {
    const orders = await Api.getOrders(getToken());
    if (orders.length === 0) {
      tbody.innerHTML = `<tr><td colspan="6">No orders yet.</td></tr>`;
      return;
    }
    tbody.innerHTML = orders.map((o) => `
      <tr>
        <td>#${o.id}</td>
        <td>${escapeHtml(o.customer.name)}<br><small>${escapeHtml(o.customer.email)}</small></td>
        <td>${o.items.map((i) => `${escapeHtml(i.name)} &times;${i.qty}`).join('<br>')}</td>
        <td>$${o.total.toFixed(2)}</td>
        <td><span class="status-pill">${escapeHtml(o.status)}</span></td>
        <td class="table-actions">
          <button data-advance="${o.id}" data-status="${nextStatus(o.status)}">Mark ${nextStatus(o.status)}</button>
        </td>
      </tr>
    `).join('');
  } catch (err) {
    tbody.innerHTML = `<tr><td colspan="6">Couldn't load orders.</td></tr>`;
  }
}

function nextStatus(current) {
  const flow = ['received', 'preparing', 'out for delivery', 'delivered'];
  const idx = flow.indexOf(current);
  return flow[Math.min(idx + 1, flow.length - 1)];
}

document.getElementById('order-table-body').addEventListener('click', async (e) => {
  const btn = e.target.closest('[data-advance]');
  if (!btn) return;
  try {
    await Api.updateOrderStatus(btn.dataset.advance, btn.dataset.status, getToken());
    loadOrders();
  } catch (err) {
    alert(err.message);
  }
});

// ---------- Init ----------
document.addEventListener('DOMContentLoaded', () => {
  if (getToken()) {
    showDashboard();
  } else {
    showLogin();
  }
});
