async function renderCart() {
  const container = document.getElementById('cart-content');
  const items = CartStore.getItems();

  if (items.length === 0) {
    container.innerHTML = `
      <div class="empty-state">
        <p>Your cart is empty.</p>
        <a class="btn btn-primary" href="index.html#products">Browse Products</a>
      </div>`;
    return;
  }

  let products;
  try {
    products = await Api.getProducts();
  } catch (err) {
    container.innerHTML = `<p>Couldn't load your cart. Is the backend server running?</p>`;
    return;
  }

  const rows = [];
  let total = 0;

  items.forEach((item) => {
    const product = products.find((p) => p.id === item.productId);
    if (!product) return;
    const lineTotal = product.price * item.qty;
    total += lineTotal;

    rows.push(`
      <div class="cart-row" data-row="${product.id}">
        <div class="cart-thumb">${getIcon(product.icon)}</div>
        <div>
          <h4>${escapeHtml(product.name)}</h4>
          <div class="unit-price">$${product.price.toFixed(2)} / ${escapeHtml(product.unit)}</div>
        </div>
        <div class="qty-control">
          <button data-qty-down="${product.id}" aria-label="Decrease quantity">&minus;</button>
          <span>${item.qty}</span>
          <button data-qty-up="${product.id}" aria-label="Increase quantity">+</button>
        </div>
        <div class="line-total">$${lineTotal.toFixed(2)}</div>
        <button class="remove-btn" data-remove="${product.id}">Remove</button>
      </div>
    `);
  });

  container.innerHTML = `
    <div class="cart-layout">
      <div class="cart-items">${rows.join('')}</div>
      <div class="cart-summary">
        <h3>Order Summary</h3>
        <div class="summary-row"><span>Subtotal</span><span>$${total.toFixed(2)}</span></div>
        <div class="summary-row"><span>Delivery</span><span>Free</span></div>
        <div class="summary-row total"><span>Total</span><span>$${total.toFixed(2)}</span></div>
        <a class="btn btn-primary" href="checkout.html">Checkout</a>
      </div>
    </div>
  `;

  container.addEventListener('click', handleCartClick);
}

function handleCartClick(e) {
  const up = e.target.closest('[data-qty-up]');
  const down = e.target.closest('[data-qty-down]');
  const remove = e.target.closest('[data-remove]');

  if (up) {
    const items = CartStore.getItems();
    const item = items.find((i) => i.productId === up.dataset.qtyUp);
    CartStore.setQty(up.dataset.qtyUp, (item ? item.qty : 0) + 1);
    renderCart();
  } else if (down) {
    const items = CartStore.getItems();
    const item = items.find((i) => i.productId === down.dataset.qtyDown);
    CartStore.setQty(down.dataset.qtyDown, (item ? item.qty : 1) - 1);
    renderCart();
  } else if (remove) {
    CartStore.removeItem(remove.dataset.remove);
    renderCart();
  }
}

document.addEventListener('DOMContentLoaded', renderCart);
