// Thin fetch wrapper for talking to the backend API.
const API_BASE = '/api';

async function apiRequest(path, options = {}) {
  const res = await fetch(API_BASE + path, {
    headers: { 'Content-Type': 'application/json', ...(options.headers || {}) },
    ...options
  });

  let data = null;
  try { data = await res.json(); } catch (e) { /* no body */ }

  if (!res.ok) {
    const message = (data && data.error) || `Request failed (${res.status})`;
    throw new Error(message);
  }
  return data;
}

const Api = {
  getProducts: () => apiRequest('/products'),
  getProduct: (id) => apiRequest(`/products/${id}`),
  createProduct: (product, token) =>
    apiRequest('/products', {
      method: 'POST',
      headers: { Authorization: `Bearer ${token}` },
      body: JSON.stringify(product)
    }),
  updateProduct: (id, product, token) =>
    apiRequest(`/products/${id}`, {
      method: 'PUT',
      headers: { Authorization: `Bearer ${token}` },
      body: JSON.stringify(product)
    }),
  deleteProduct: (id, token) =>
    apiRequest(`/products/${id}`, {
      method: 'DELETE',
      headers: { Authorization: `Bearer ${token}` }
    }),
  placeOrder: (order) =>
    apiRequest('/orders', { method: 'POST', body: JSON.stringify(order) }),
  getOrders: (token) =>
    apiRequest('/orders', { headers: { Authorization: `Bearer ${token}` } }),
  updateOrderStatus: (id, status, token) =>
    apiRequest(`/orders/${id}/status`, {
      method: 'PUT',
      headers: { Authorization: `Bearer ${token}` },
      body: JSON.stringify({ status })
    }),
  login: (username, password) =>
    apiRequest('/admin/login', { method: 'POST', body: JSON.stringify({ username, password }) })
};
