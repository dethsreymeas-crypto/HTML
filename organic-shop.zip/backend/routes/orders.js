const express = require('express');
const { nanoid } = require('nanoid');
const { readDb, writeDb } = require('../db');
const { requireAdmin } = require('../middleware/auth');

const router = express.Router();

// POST /api/orders - place an order (public)
router.post('/', (req, res) => {
  const { items, customer } = req.body;

  if (!Array.isArray(items) || items.length === 0) {
    return res.status(400).json({ error: 'Order must include at least one item.' });
  }
  if (!customer || !customer.name || !customer.email || !customer.address) {
    return res.status(400).json({ error: 'Customer name, email and address are required.' });
  }

  const db = readDb();
  let total = 0;
  const lineItems = [];

  for (const item of items) {
    const product = db.products.find((p) => p.id === item.productId);
    if (!product) {
      return res.status(400).json({ error: `Unknown product: ${item.productId}` });
    }
    const qty = Math.max(1, Number(item.qty) || 1);
    const lineTotal = product.price * qty;
    total += lineTotal;
    lineItems.push({
      productId: product.id,
      name: product.name,
      price: product.price,
      qty,
      lineTotal: Number(lineTotal.toFixed(2))
    });
  }

  const order = {
    id: nanoid(10),
    createdAt: new Date().toISOString(),
    customer,
    items: lineItems,
    total: Number(total.toFixed(2)),
    status: 'received'
  };

  db.orders.unshift(order);
  writeDb(db);

  res.status(201).json(order);
});

// GET /api/orders - list all orders (admin only)
router.get('/', requireAdmin, (req, res) => {
  const db = readDb();
  res.json(db.orders);
});

// GET /api/orders/:id - single order (admin only)
router.get('/:id', requireAdmin, (req, res) => {
  const db = readDb();
  const order = db.orders.find((o) => o.id === req.params.id);
  if (!order) return res.status(404).json({ error: 'Order not found.' });
  res.json(order);
});

// PUT /api/orders/:id/status - update order status (admin only)
router.put('/:id/status', requireAdmin, (req, res) => {
  const db = readDb();
  const order = db.orders.find((o) => o.id === req.params.id);
  if (!order) return res.status(404).json({ error: 'Order not found.' });

  const { status } = req.body;
  if (!status) return res.status(400).json({ error: 'status is required.' });

  order.status = status;
  writeDb(db);
  res.json(order);
});

module.exports = router;
